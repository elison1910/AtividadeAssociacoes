package Sistema_Funcionarios;

public class Atendente extends Funcionarios {
    private String idCliente;
    private int numeroAtendimentos;
    private int metaAtendimentos;
    private String feedbackCliente;

    // Construtor
    public Atendente(String nome, int idade, String cpf, String email, Float salario, String departamento,
            int cargaHoraria, String idCliente, int numeroAtendimentos, int metaAtendimentos,
            String feedbackCliente, Endereco endereco) {
        super(nome, idade, cpf, email, salario, departamento, cargaHoraria, endereco);

        this.idCliente = idCliente;
        this.numeroAtendimentos = numeroAtendimentos;
        this.metaAtendimentos = metaAtendimentos;
        this.feedbackCliente = feedbackCliente;
    }

    // Getters e Setters
    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public int getNumeroAtendimentos() {
        return numeroAtendimentos;
    }

    public void setNumeroAtendimentos(int numeroAtendimentos) {
        this.numeroAtendimentos = numeroAtendimentos;
    }

    public int getMetaAtendimentos() {
        return metaAtendimentos;
    }

    public void setMetaAtendimentos(int metaAtendimentos) {
        this.metaAtendimentos = metaAtendimentos;
    }

    public String getFeedbackCliente() {
        return feedbackCliente;
    }

    public void setFeedbackCliente(String feedbackCliente) {
        this.feedbackCliente = feedbackCliente;
    }
}