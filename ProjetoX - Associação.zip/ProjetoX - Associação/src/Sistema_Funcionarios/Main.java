package Sistema_Funcionarios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Listas para armazenar as instâncias
        List<Atendente> atendentes = new ArrayList<>();
        List<Gerente> gerentes = new ArrayList<>();

        // Cadastro de Atendentes
        System.out.println("Cadastro de Atendentes:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Atendente " + (i + 1) + ":");
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Salário: ");
            Float salario = Float.parseFloat(scanner.nextLine());
            System.out.print("Departamento: ");
            String departamento = scanner.nextLine();
            System.out.print("Carga Horária: ");
            int cargaHoraria = Integer.parseInt(scanner.nextLine());

            // Dados do endereço
            System.out.print("Rua: ");
            String rua = scanner.nextLine();
            System.out.print("Número: ");
            String numero = scanner.nextLine();
            System.out.print("Cidade: ");
            String cidade = scanner.nextLine();
            System.out.print("Estado: ");
            String estado = scanner.nextLine();
            System.out.print("CEP: ");
            String cep = scanner.nextLine();

            Endereco endereco = new Endereco(rua, numero, cidade, estado, cep);

            // Dados específicos do atendente
            System.out.print("ID do Cliente: ");
            String idCliente = scanner.nextLine();
            System.out.print("Número de Atendimentos: ");
            int numeroAtendimentos = Integer.parseInt(scanner.nextLine());
            System.out.print("Meta de Atendimentos: ");
            int metaAtendimentos = Integer.parseInt(scanner.nextLine());
            System.out.print("Feedback do Cliente: ");
            String feedbackCliente = scanner.nextLine();

            Atendente atendente = new Atendente(nome, idade, cpf, email, salario, departamento,
                    cargaHoraria, idCliente, numeroAtendimentos, metaAtendimentos,
                    feedbackCliente, endereco);

            atendentes.add(atendente);
        }

        // Cadastro de Gerentes
        System.out.println("\nCadastro de Gerentes:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Gerente " + (i + 1) + ":");
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Salário: ");
            Float salario = Float.parseFloat(scanner.nextLine());
            System.out.print("Departamento: ");
            String departamento = scanner.nextLine();
            System.out.print("Carga Horária: ");
            int cargaHoraria = Integer.parseInt(scanner.nextLine());

            // Dados do endereço
            System.out.print("Rua: ");
            String rua = scanner.nextLine();
            System.out.print("Número: ");
            String numero = scanner.nextLine();
            System.out.print("Cidade: ");
            String cidade = scanner.nextLine();
            System.out.print("Estado: ");
            String estado = scanner.nextLine();
            System.out.print("CEP: ");
            String cep = scanner.nextLine();

            Endereco endereco = new Endereco(rua, numero, cidade, estado, cep);

            // Dados específicos do gerente
            System.out.print("Equipe: ");
            String equipe = scanner.nextLine();
            System.out.print("Objetivos: ");
            String objetivos = scanner.nextLine();
            System.out.print("Bônus Anual: ");
            Float bonusAnual = Float.parseFloat(scanner.nextLine());
            System.out.print("Nível de Gerência (junior/pleno/senior): ");
            String nivelGerencia = scanner.nextLine();

            Gerente gerente = new Gerente(nome, idade, cpf, email, salario, departamento,
                    cargaHoraria, equipe, objetivos, bonusAnual, nivelGerencia,
                    endereco);

            gerentes.add(gerente);
        }

        // Impressão dos dados dos Atendentes
        System.out.println("\nDados dos Atendentes:");
        for (Atendente atendente : atendentes) {
            imprimirDadosAtendente(atendente);
        }

        // Impressão dos dados dos Gerentes
        System.out.println("\nDados dos Gerentes:");
        for (Gerente gerente : gerentes) {
            imprimirDadosGerente(gerente);
        }

        scanner.close();
    }

    private static void imprimirDadosAtendente(Atendente atendente) {
        Endereco endereco = atendente.getEndereco();
        System.out.println("\nNome: " + atendente.getNome());
        System.out.println("Idade: " + atendente.getIdade());
        System.out.println("Email: " + atendente.getEmail());
        System.out.println("ID do Cliente: " + atendente.getIdCliente());
        System.out.println("Endereço: " + endereco.getRua() + ", " + endereco.getNumero() +
                ", " + endereco.getCidade() + ", " + endereco.getEstado() + ", " +
                endereco.getCep());
    }

    private static void imprimirDadosGerente(Gerente gerente) {
        Endereco endereco = gerente.getEndereco();
        System.out.println("\nNome: " + gerente.getNome());
        System.out.println("Idade: " + gerente.getIdade());
        System.out.println("Email: " + gerente.getEmail());
        System.out.println("Equipe: " + gerente.getEquipe());
        System.out.println("Endereço: " + endereco.getRua() + ", " + endereco.getNumero() +
                ", " + endereco.getCidade() + ", " + endereco.getEstado() + ", " +
                endereco.getCep());
    }
}